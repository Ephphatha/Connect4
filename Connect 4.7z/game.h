/* Andrew James
** Date Created: 2008/11/21
** Last Modified: 2008/12/06
** game.h
** Function declarations for the connect 4 game.
*/
#ifndef __game
#define __game
#include <windows.h>

BOOL ClearGame(short** gameState, int gridWidth, int gridHeight,
               short* activePlayer);

int CheckRuns(short** gameState, int gridWidth, int gridHeight, int x, int y);

int DoInput(short** gameState, int gridWidth, int gridHeight,
            int column, short activePlayer);
#endif
