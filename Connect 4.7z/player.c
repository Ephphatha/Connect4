/* Andrew James
** Date Created: 2008/12/06
** Last Modified: 2008/12/08
** player.c
** Function definitions for the connect 4 game.
*/
#include "player.h"

BOOL AddPlayer(PLAYER **players,
               short *totalPlayers,
               short *maxPlayers,
               char* name,
               COLORREF colour,
               BOOL isLocal,
               BOOL isPlaying,
               BOOL isAI)
{
    if(*totalPlayers >= *maxPlayers)
    {
        short newMaxPlayers = *maxPlayers * 2;
        PLAYER *newPlayers = (PLAYER*)calloc(newMaxPlayers, sizeof(PLAYER));

        if(newPlayers)
        {
            memcpy(newPlayers, *players, *totalPlayers * sizeof(PLAYER));
            free(*players);
            *players = newPlayers;
            *maxPlayers = newMaxPlayers;
        }
    }

    if(*totalPlayers < *maxPlayers)
    {
        strncpy((*players)[*totalPlayers].name, name, 19);
        (*players)[*totalPlayers].name[19] = '\0';
        (*players)[*totalPlayers].colour = colour;
        (*players)[*totalPlayers].isAI = isAI;
        (*players)[*totalPlayers].isLocal = isLocal;
        (*players)[*totalPlayers].isPlaying = isPlaying;
        (*totalPlayers)++;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int NextPlayer(PLAYER *players,
               short totalPlayers,
               short *activePlayer)
{
    int validPlayers = 0;
    int playerToMove = (*activePlayer);
    for(int i = 0; i < totalPlayers; i++)
    {
        if(players[i].isPlaying)
        {
            validPlayers++;
        }
    }

    if(validPlayers)
    {
        do
        {
            if(playerToMove >= totalPlayers)
            {
                playerToMove = 0;
            }
            else
            {
                playerToMove++;
            }
        }
        while(!players[playerToMove].isPlaying);
    }

    (*activePlayer) = playerToMove;

    return validPlayers;
}
