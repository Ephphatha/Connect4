/* Andrew James
** Date Created: 2008/12/06
** Last Modified: 2008/12/06
** player.h
** Function declarations for the connect 4 game.
*/
#ifndef __player
#define __player
#include <windows.h>

typedef struct _player
{
    char name[20];
    COLORREF colour;
    int score;
    int moves;
    BOOL isAI;
    BOOL isLocal;
    BOOL isPlaying;
} PLAYER;

BOOL AddPlayer(PLAYER **players,
               short *totalPlayers,
               short *maxplayers,
               char *name,
               COLORREF colour,
               BOOL isLocal,
               BOOL isPlaying,
               BOOL isAI);

int NextPlayer(PLAYER *players,
               short totalPlayers,
               short *activePlayer);
#endif
