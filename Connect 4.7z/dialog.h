/* Andrew James
** Date Created: 2008/12/06
** Last Modified: 2008/12/06
** dialog.h
** Function declarations for the connect 4 game.
*/
#ifndef __dialog
#define __dialog
#include <windows.h>
#include "resource.h"

//Values for messages the application uses.
#define CONNECT 0x8042
#define CLEARGAME 0x8084
#define HOSTGAME 0x80C6
#define INPUT 0x8108

INT_PTR CALLBACK DlgProcConnect(HWND, UINT, WPARAM, LPARAM);

INT_PTR CALLBACK DlgProcHost(HWND, UINT, WPARAM, LPARAM);

#endif
