/* Andrew James
** Date Created: 2008/12/06
** Last Modified: 2008/12/06
** dialog.c
** Function definitions for the connect 4 game.
*/
#include "dialog.h"

INT_PTR CALLBACK DlgProcConnect(HWND hwnd,
                                UINT message,
                                WPARAM wParam,
                                LPARAM lParam)
{
    char ip[16], port[6];
    switch(message)
    {
        case WM_INITDIALOG:
            return 1;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDCANCEL:
                    DestroyWindow(hwnd);
                    break;

                case IDC_BTNCONNECT:
                    GetDlgItemText(hwnd, IDC_IPADDRESS, ip, 16);
                    GetDlgItemText(hwnd, IDC_CONNECTPORT, port, 6);
                    SendMessage(GetWindow(hwnd, GW_OWNER), CONNECT,
                                (WPARAM)ip, (LPARAM)port);
                    DestroyWindow(hwnd);
                    break;
            }
            return 1;

        default:
            return 0;
    }
}

INT_PTR CALLBACK DlgProcHost(HWND hwnd,
                             UINT message,
                             WPARAM wParam,
                             LPARAM lParam)
{
    char port[6];
    switch(message)
    {
        case WM_INITDIALOG:
            return 1;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDCANCEL:
                    DestroyWindow(hwnd);
                    break;

                case IDC_BTNHOST:
                    GetDlgItemText(hwnd, IDC_HOSTPORT, port, 6);
                    SendMessage(GetWindow(hwnd, GW_OWNER), HOSTGAME,
                                (WPARAM)port, 0);
                    DestroyWindow(hwnd);
                    break;
            }
            return 1;

        default:
            return 0;
    }
}
